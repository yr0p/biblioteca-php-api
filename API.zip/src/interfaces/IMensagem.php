<?php

namespace src\interfaces;

interface IMensagem
{
    public static function mostrarMensagem($code, $mensagem);
}