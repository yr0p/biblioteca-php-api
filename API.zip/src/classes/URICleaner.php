<?php
namespace src\classes;

class URICleaner{
    public static function cleanURL($URL){
        $data = explode("/", $URL);
    }
}